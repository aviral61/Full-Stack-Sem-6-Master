import React from "react";
import { Link } from "react-router-dom";

const Home = () => {
  return (
    <header className="navbar">
      <h1 className="logo">Home Page</h1>

      <nav>
        <ul className="nav-links">
          <li>
            <Link to="/" className="nav-link">
              Home
            </Link>
          </li>
          <li>
            <Link to="/about" className="nav-link">
              About
            </Link>
          </li>
        </ul>
      </nav>

      <h2 className="username">Aviral Srivastava</h2>
    </header>
  );
};

export default Home;