import React from "react";


const About = () => {
  return (
    <section className="about-container">
      <h1 className="about-title">About Me</h1>

      <div className="about-card">
        <p>
          Hello, I am <strong>Aviral Srivastava</strong>, a third-year Computer Science
          student with a strong interest in software development, web
          technologies, and problem solving.
        </p>

        <p>
          I have hands-on experience with <strong>C, C++, Python, and
          JavaScript</strong>. I enjoy building real-world projects such as web
          applications and IoT-based systems.
        </p>

        <p>
          My goal is to become a skilled software engineer and continuously
          improve my technical knowledge and problem-solving abilities.
        </p>
      </div>
    </section>
  );
};

export default About;